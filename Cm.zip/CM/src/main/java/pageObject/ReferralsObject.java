package pageObject;

public class ReferralsObject {
	

}
